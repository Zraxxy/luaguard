# LuaGuard — private Lua management starter

This is a private, single-owner starter project. It includes login, script records,
one-time key generation, key revocation, a basic verification API, and encrypted
source backups.

## Run in GitHub Codespaces

1. Open this repository in a Codespace.
2. In the terminal run:

```bash
python -m pip install -r requirements.txt
python -c "import secrets; print('APP_SECRET=' + secrets.token_hex(32))"
python -c "from cryptography.fernet import Fernet; print('LOCKER_KEY=' + Fernet.generate_key().decode())"
```

3. Copy the two generated values. Set them in the terminal (replace the example values):

```bash
export APP_SECRET='paste-first-value'
export LOCKER_KEY='paste-second-value'
python app.py
```

4. Open the forwarded port 5000 in the Codespaces Ports tab.
5. Create your owner account. Registration automatically closes after the first account.

## Important security notes

- This is a development starter, not a claim of uncrackable protection.
- Keep the Codespace private. Never commit `.env`, secrets, real scripts, or keys.
- Backups are encrypted on the server using `LOCKER_KEY`. If you lose that key,
  backups cannot be decrypted. Store it securely offline.
- For deployment, use HTTPS, secure cookies, CSRF protection, rate limiting,
  backups, dependency updates, and a production WSGI server.
- Lua client-side code can be inspected by a determined user. Keep sensitive
  logic and secrets server-side where possible.
- The API endpoint is a starter and should not be exposed publicly until
  rate limiting, HTTPS, monitoring, and abuse controls are added.
