import os, secrets, hashlib
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError

APP_SECRET = os.environ.get("APP_SECRET")
LOCKER_KEY = os.environ.get("LOCKER_KEY")
if not APP_SECRET or not LOCKER_KEY:
    raise RuntimeError("Set APP_SECRET and LOCKER_KEY environment variables before starting.")

app = Flask(__name__)
app.secret_key = APP_SECRET
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
)
fernet = Fernet(LOCKER_KEY.encode())
engine = create_engine("sqlite:///luaguard.db", future=True)

def init_db():
    with engine.begin() as c:
        c.execute(text("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL, created_at TEXT NOT NULL)"""))
        c.execute(text("""CREATE TABLE IF NOT EXISTS scripts (
            id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL,
            description TEXT DEFAULT '', created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id))"""))
        c.execute(text("""CREATE TABLE IF NOT EXISTS keys (
            id INTEGER PRIMARY KEY, script_id INTEGER NOT NULL, key_hash TEXT UNIQUE NOT NULL,
            key_prefix TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
            device_id TEXT DEFAULT '', created_at TEXT NOT NULL,
            FOREIGN KEY(script_id) REFERENCES scripts(id))"""))
        c.execute(text("""CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY, script_id INTEGER NOT NULL, filename TEXT NOT NULL,
            encrypted_source BLOB NOT NULL, created_at TEXT NOT NULL,
            FOREIGN KEY(script_id) REFERENCES scripts(id))"""))

def now():
    return datetime.now(timezone.utc).isoformat()

def current_user():
    return session.get("user_id")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def owned_script(script_id, user_id):
    with engine.connect() as c:
        row = c.execute(text("SELECT * FROM scripts WHERE id=:sid AND user_id=:uid"),
                        {"sid": script_id, "uid": user_id}).mappings().first()
    return row

@app.route("/")
def index():
    return redirect(url_for("dashboard") if current_user() else url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    with engine.connect() as c:
        count = c.execute(text("SELECT COUNT(*) FROM users")).scalar_one()
    # Single-owner private installation: only the first account can register.
    if count:
        flash("Registration is closed. This private installation already has an owner.")
        return redirect(url_for("login"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 12:
            flash("Use a username of at least 3 characters and password of at least 12 characters.")
            return render_template("register.html")
        with engine.begin() as c:
            c.execute(text("INSERT INTO users(username,password_hash,created_at) VALUES(:u,:p,:d)"),
                      {"u": username, "p": generate_password_hash(password), "d": now()})
            uid = c.execute(text("SELECT id FROM users WHERE username=:u"), {"u": username}).scalar_one()
        session["user_id"] = uid
        session.permanent = True
        return redirect(url_for("dashboard"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with engine.connect() as c:
            user = c.execute(text("SELECT * FROM users WHERE username=:u"), {"u": username}).mappings().first()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session.permanent = True
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    with engine.connect() as c:
        scripts = c.execute(text("""SELECT s.*,
            (SELECT COUNT(*) FROM keys k WHERE k.script_id=s.id) AS key_count,
            (SELECT COUNT(*) FROM backups b WHERE b.script_id=s.id) AS backup_count
            FROM scripts s WHERE s.user_id=:uid ORDER BY s.id DESC"""),
            {"uid": current_user()}).mappings().all()
    return render_template("dashboard.html", scripts=scripts)

@app.route("/scripts/create", methods=["POST"])
@login_required
def create_script():
    name = request.form.get("name", "").strip()
    desc = request.form.get("description", "").strip()
    if not name or len(name) > 80:
        flash("Script name is required (80 characters max).")
        return redirect(url_for("dashboard"))
    with engine.begin() as c:
        c.execute(text("INSERT INTO scripts(user_id,name,description,created_at) VALUES(:u,:n,:d,:t)"),
                  {"u": current_user(), "n": name, "d": desc[:500], "t": now()})
    flash("Script created.")
    return redirect(url_for("dashboard"))

@app.route("/scripts/<int:script_id>")
@login_required
def script_detail(script_id):
    script = owned_script(script_id, current_user())
    if not script: abort(404)
    with engine.connect() as c:
        keys = c.execute(text("SELECT id,key_prefix,active,device_id,created_at FROM keys WHERE script_id=:s ORDER BY id DESC"),
                         {"s": script_id}).mappings().all()
        backups = c.execute(text("SELECT id,filename,created_at FROM backups WHERE script_id=:s ORDER BY id DESC"),
                            {"s": script_id}).mappings().all()
    return render_template("script.html", script=script, keys=keys, backups=backups)

@app.route("/scripts/<int:script_id>/keys/create", methods=["POST"])
@login_required
def create_key(script_id):
    if not owned_script(script_id, current_user()): abort(404)
    raw = "LG-" + secrets.token_urlsafe(24)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    with engine.begin() as c:
        c.execute(text("INSERT INTO keys(script_id,key_hash,key_prefix,created_at) VALUES(:s,:h,:p,:t)"),
                  {"s": script_id, "h": digest, "p": raw[:10], "t": now()})
    # Show the full key only once.
    return render_template("key_created.html", key_value=raw, script_id=script_id)

@app.route("/keys/<int:key_id>/toggle", methods=["POST"])
@login_required
def toggle_key(key_id):
    with engine.begin() as c:
        row = c.execute(text("""SELECT k.id,k.active,s.user_id FROM keys k
            JOIN scripts s ON s.id=k.script_id WHERE k.id=:k"""), {"k": key_id}).mappings().first()
        if not row or row["user_id"] != current_user(): abort(404)
        c.execute(text("UPDATE keys SET active=:a WHERE id=:k"),
                  {"a": 0 if row["active"] else 1, "k": key_id})
    return redirect(request.referrer or url_for("dashboard"))

@app.route("/scripts/<int:script_id>/backup", methods=["POST"])
@login_required
def backup_source(script_id):
    if not owned_script(script_id, current_user()): abort(404)
    source = request.files.get("source")
    if not source or not source.filename:
        flash("Choose a Lua source file.")
        return redirect(url_for("script_detail", script_id=script_id))
    if source.content_length and source.content_length > 2_000_000:
        flash("File is too large (2 MB maximum).")
        return redirect(url_for("script_detail", script_id=script_id))
    data = source.read(2_000_001)
    if len(data) > 2_000_000:
        flash("File is too large (2 MB maximum).")
        return redirect(url_for("script_detail", script_id=script_id))
    encrypted = fernet.encrypt(data)
    filename = os.path.basename(source.filename)[:120]
    with engine.begin() as c:
        c.execute(text("INSERT INTO backups(script_id,filename,encrypted_source,created_at) VALUES(:s,:f,:b,:t)"),
                  {"s": script_id, "f": filename, "b": encrypted, "t": now()})
    flash("Encrypted backup saved.")
    return redirect(url_for("script_detail", script_id=script_id))

@app.route("/backups/<int:backup_id>/download")
@login_required
def download_backup(backup_id):
    from flask import Response
    with engine.connect() as c:
        row = c.execute(text("""SELECT b.* FROM backups b JOIN scripts s ON s.id=b.script_id
            WHERE b.id=:b AND s.user_id=:u"""), {"b": backup_id, "u": current_user()}).mappings().first()
    if not row: abort(404)
    try:
        data = fernet.decrypt(row["encrypted_source"])
    except InvalidToken:
        abort(500)
    return Response(data, mimetype="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{row["filename"]}"'})

@app.route("/api/verify", methods=["POST"])
def api_verify():
    """Your Lua client can POST JSON: {key: 'LG-...', device_id: 'optional-id'}.
    This endpoint checks key status. Use HTTPS and add rate limiting before public deployment.
    """
    body = request.get_json(silent=True) or {}
    raw_key = body.get("key", "")
    device_id = body.get("device_id", "")
    if not isinstance(raw_key, str) or not raw_key or len(raw_key) > 150:
        return jsonify(valid=False), 400
    digest = hashlib.sha256(raw_key.encode()).hexdigest()
    with engine.begin() as c:
        row = c.execute(text("SELECT * FROM keys WHERE key_hash=:h"), {"h": digest}).mappings().first()
        if not row or not row["active"]:
            return jsonify(valid=False), 401
        if row["device_id"] and row["device_id"] != device_id:
            return jsonify(valid=False, reason="device_mismatch"), 403
        if device_id and not row["device_id"]:
            c.execute(text("UPDATE keys SET device_id=:d WHERE id=:i"),
                      {"d": device_id[:200], "i": row["id"]})
    return jsonify(valid=True)

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", message="That page was not found."), 404

init_db()
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
